<?php return array (
  'asignar-controller' => 'App\\Http\\Livewire\\AsignarController',
  'card-controller' => 'App\\Http\\Livewire\\CardController',
  'categories-controller' => 'App\\Http\\Livewire\\CategoriesController',
  'patients-controller' => 'App\\Http\\Livewire\\PatientsController',
  'permisos-controller' => 'App\\Http\\Livewire\\PermisosController',
  'reports-controller' => 'App\\Http\\Livewire\\ReportsController',
  'roles-controller' => 'App\\Http\\Livewire\\RolesController',
  'users-controller' => 'App\\Http\\Livewire\\UsersController',
  'vaccines-controller' => 'App\\Http\\Livewire\\VaccinesController',
);