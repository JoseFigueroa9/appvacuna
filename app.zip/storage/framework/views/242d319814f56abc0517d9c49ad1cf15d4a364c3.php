</div>
      <div class="modal-footer">

        <button type="button" wire:click.prevent="resetUI()" class="btn btn-dark close-btn text-info" data-dismiss="modal">Cerrar</button>
        <?php if($selected_id < 1): ?>
        <button type="button" wire:click.prevent="Store()" class="btn btn-dark close-modal">Guardar</button>
        <?php else: ?>
        <button type="button" wire:click.prevent="Update()" class="btn btn-dark close-modal">Actualizar</button>
        <?php endif; ?>
        
      </div>
    </div>
  </div>
</div><?php /**PATH C:\laragon\www\sisvacuna\resources\views/common/modalFooter.blade.php ENDPATH**/ ?>