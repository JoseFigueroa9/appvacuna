<div class="row">
    <div class="col-sm-12">
        <div>
            <div class="connect-sorting">
                <h5 class="text-center mb-3">Resumen de Ficha</h5>
                <div class="connect-sorting-content">
                    <div class="card simple-title-task ui-sortable-handle">
                        <div class="card-body">
                            <div class="task-header">
                                <div>
                                    <h2>Fecha: <?php echo e($total); ?></h2>
                                    <input type="hidden" id="hiddenTotal" value="<?php echo e($total); ?>">
                                </div>
                                <div>
                                    <h4 class="mt-3">Vacunas: <?php echo e($itemsQuantity); ?></h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\laragon\www\vacunas\resources\views/livewire/pos/partials/total.blade.php ENDPATH**/ ?>