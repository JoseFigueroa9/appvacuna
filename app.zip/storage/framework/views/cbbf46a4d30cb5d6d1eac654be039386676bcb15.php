<div>
    <style></style>

    <div class="row layout-top-spacing">
        <div class="col-sm-12 col-md-8">
            <!-- DETALLES -->
            <?php echo $__env->make('livewire.pos.partials.detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <div class="col-sm-12 col-md-4">
            <!-- TOTAL -->
            <?php echo $__env->make('livewire.pos.partials.total', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



            <!-- DENOMINACIONES -->
            
        </div>

    </div>



</div>

<script>

</script>
<?php /**PATH C:\laragon\www\sisvacuna\resources\views/livewire/pos/component.blade.php ENDPATH**/ ?>