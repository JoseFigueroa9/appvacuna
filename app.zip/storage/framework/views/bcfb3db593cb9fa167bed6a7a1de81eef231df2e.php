<?php echo $__env->make('common.modalHead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row">
    <div class="col-sm-6 col-md-4">
        <div class="form-group">
            <label>Nombres</label>
            <input type="text" wire:model.lazy="name" class="form-control" placeholder="Ej: Carlos Estefano">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger er"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
        </div>
    </div>

    <div class="col-sm-6 col-md-4">
        <div class="form-group">
            <label>Apellidos</label>
            <input type="text" wire:model.lazy="lastname" class="form-control" placeholder="Ej: Ramirez Ventura">
            <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger er"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
        </div>
    </div>

    <div class="col-sm-6 col-md-4">
        <div class="form-group">
            <label>DNI</label>
            <input type="text" wire:model.lazy="dni" class="form-control" placeholder="Ej: 77788899">
            <?php $__errorArgs = ['dni'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger er"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
        </div>
    </div>

    <div class="col-sm-6 col-md-4">
        <div class="form-group">
            <label>Teléfono</label>
            <input type="tel" wire:model.lazy="phone" class="form-control" placeholder="Ej: 999999999">
            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger er"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
        </div>
    </div>

    <div class="col-sm-6 col-md-4">
        <div class="form-group">
            <label>E-mail</label>
            <input type="email" wire:model.lazy="email" class="form-control" placeholder="Ej: ejemplo@gmail.com">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger er"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
        </div>
    </div>

    <div class="col-sm-6 col-md-4">
        <div class="form-group">
            <label>Fecha Nacimiento</label>
            <input type="date" wire:model.lazy="date_birth" class="form-control">
            <?php $__errorArgs = ['date_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger er"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
        </div>
    </div>

    <div class="col-sm-6 col-md-4">
        <div class="form-group">
            <label>Sexo</label>
            <input type="text" wire:model.lazy="gender" class="form-control" placeholder="Ej: Masculino">
            <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger er"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
        </div>
    </div>

    <div class="col-sm-6 col-md-4">
        <div class="form-group">
            <label>Nombre Padre</label>
            <input type="text" wire:model.lazy="father_fullname" class="form-control" placeholder="Ej: Jorge Ramirez">
            <?php $__errorArgs = ['father_fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger er"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
        </div>
    </div>

    <div class="col-sm-6 col-md-4">
        <div class="form-group">
            <label>DNI Padre</label>
            <input type="text" wire:model.lazy="father_dni" class="form-control" placeholder="Ej: 66677788">
            <?php $__errorArgs = ['father_dni'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger er"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
        </div>
    </div>

    <div class="col-sm-6 col-md-4">
        <div class="form-group">
            <label>Nombre Madre</label>
            <input type="text" wire:model.lazy="mother_fullname" class="form-control" placeholder="Ej: Zoyla Ventura">
            <?php $__errorArgs = ['mother_fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger er"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
        </div>
    </div>

    <div class="col-sm-6 col-md-4">
        <div class="form-group">
            <label>DNI Madre</label>
            <input type="text" wire:model.lazy="mother_dni" class="form-control" placeholder="Ej: 66677788">
            <?php $__errorArgs = ['mother_dni'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger er"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
        </div>
    </div>
    
</div>

<?php echo $__env->make('common.modalFooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sisvacuna\resources\views/livewire/patient/form.blade.php ENDPATH**/ ?>