<?php echo $__env->make('common.modalHead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h4 class="card-title">
    <b>Datos del Paciente</b>
</h4>
<div class="row">
    <div class="col-sm-6 col-md-3">
        <div class="form-group">
            <label>DNI</label>
            <?php if($selected_id < 1): ?>
                <input type="text" wire:model.lazy="dni" wire:blur="LoadDni()" class="form-control"
                    placeholder="Ej: 77788899">
                <?php $__errorArgs = ['dni'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger er"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php else: ?>
                <input type="text" wire:model.lazy="dni" class="form-control disabled" disabled>
            <?php endif; ?>
        </div>
    </div>

    <div class="col-sm-6 col-md-3">
        <div class="form-group">
            <label>Nombres</label>
            <input type="text" wire:model.lazy="patient.name" class="form-control disabled" disabled>
        </div>
    </div>

    <div class="col-sm-6 col-md-3">
        <div class="form-group">
            <label>Apellidos</label>
            <input type="text" wire:model.lazy="patient.lastname" class="form-control disabled" disabled>
        </div>
    </div>



    <div class="col-sm-6 col-md-3">
        <div class="form-group">
            <label>Teléfono</label>
            <input type="tel" wire:model.lazy="patient.phone" class="form-control disabled" disabled>
        </div>
    </div>

    <div class="col-sm-6 col-md-3">
        <div class="form-group">
            <label>E-mail</label>
            <input type="email" wire:model.lazy="patient.email" class="form-control disabled" disabled>
        </div>
    </div>

    <div class="col-sm-6 col-md-3">
        <div class="form-group">
            <label>Fecha Nacimiento</label>
            <input type="date" wire:model.lazy="patient.date_birth" class="form-control disabled" disabled>
        </div>
    </div>

    <div class="col-sm-6 col-md-3">
        <div class="form-group">
            <label>Sexo</label>
            <input type="text" wire:model.lazy="patient.gender" class="form-control disabled" disabled>
        </div>
    </div>
    <div class="col-sm-6 col-md-3">
    </div>
    <div class="col-sm-6 col-md-3">
        <div class="form-group">
            <label>Nombre Padre</label>
            <input type="text" wire:model.lazy="patient.father_fullname" class="form-control disabled" disabled>
        </div>
    </div>

    <div class="col-sm-6 col-md-3">
        <div class="form-group">
            <label>DNI Padre</label>
            <input type="text" wire:model.lazy="patient.father_dni" class="form-control disabled" disabled>
        </div>
    </div>

    <div class="col-sm-6 col-md-3">
        <div class="form-group">
            <label>Nombre Madre</label>
            <input type="text" wire:model.lazy="patient.mother_fullname" class="form-control disabled" disabled>
        </div>
    </div>

    <div class="col-sm-6 col-md-3">
        <div class="form-group">
            <label>DNI Madre</label>
            <input type="text" wire:model.lazy="patient.mother_dni" class="form-control disabled" disabled>
        </div>
    </div>
</div>
<h4 class="card-title">
    <b>Datos de la ficha de vacunación</b>
</h4>
<div class="row">

    <div class="col-sm-6 col-md-3" style="padding: 5px">
        <label>Vacunas</label>
        <select wire:model='vaccine_id' class="form-control" onchange="changeVacuna()" id="vaccine_id">
            <option value="Elegir" disabled>Elegir</option>
            <?php $__currentLoopData = $vaccines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vaccine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($vaccine->id); ?>" data-lote="<?php echo e($vaccine->lot_number); ?>"><?php echo e($vaccine->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['vaccine_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger er"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="col-sm-6 col-md-2" style="padding: 5px">
        <label>No. Dosis</label><br>
        <input type="number" min="1" wire:model.lazy="number_dosis" class="form-control">
        <?php $__errorArgs = ['number_dosis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger er"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-sm-6 col-md-2" style="padding: 5px">
        <label>No. Lote</label><br>
        <input type="text" value="<?php echo e($lot_number); ?>" class="form-control disabled" disabled id="lot_number">
    </div>
    <div class="col-sm-6 col-md-2" style="padding: 5px">
        <label>Fecha</label><br>
        <input type="date" wire:model.lazy="date" class="form-control">
        <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger er"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-sm-6 col-md-3" style="padding: 5px">
        <label>Lugar</label><br>
        <input type="text" wire:model.lazy="locale" class="form-control">
        <?php $__errorArgs = ['locale'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger er"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<?php echo $__env->make('common.modalFooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\laragon\www\vacunas\resources\views/livewire/card/form.blade.php ENDPATH**/ ?>