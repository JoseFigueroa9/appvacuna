<script src="<?php echo e(asset('assets/js/libs/jquery-3.1.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('bootstrap/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
<script src="<?php echo e(asset('js/app.js')); ?>" defer></script> <!-- Tener en cuenta este código, ayuda con buscador y paginacion -->
<script>
    $(document).ready(function() {
        App.init();
    });
</script>
<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/sweetalerts/sweetalert2.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/notification/snackbar/snackbar.min.js')); ?>"></script>.
<script src="<?php echo e(asset('plugins/nicescroll/nicescroll.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/currency/currency.js')); ?>"></script>
<script>
    function noty(msg, option = 1){
        Snackbar.show({
            text: msg.toUpperCase(),
            actionText: 'CERRAR',
            actionTextColor: '#fff',
            backgroundColor: option == 1 ? '#3b3f5c' : '#e7515a',
            pos: 'top-right'
        });
    }
</script>

<?php echo \Livewire\Livewire::scripts(); ?>

<!-- <script src="<?php echo e(asset('plugins/apex/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/dashboard/dash_2.js')); ?>"></script> -->

<?php /**PATH C:\laragon\www\sisvacuna\resources\views/layouts/theme/scripts.blade.php ENDPATH**/ ?>