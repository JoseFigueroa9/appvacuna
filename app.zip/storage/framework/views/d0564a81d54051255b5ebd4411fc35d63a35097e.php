<div>
    <style></style>

    <div class="row layout-top-spacing">
        <div class="col-sm-12 col-md-8">
            <!-- DETALLES -->
            <?php echo $__env->make('livewire.pos.partials.detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <div class="col-sm-12 col-md-4">
            <!-- TOTAL -->
            <?php echo $__env->make('livewire.pos.partials.total', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



            <!-- DENOMINACIONES -->

        </div>
        <?php echo $__env->make('livewire.pos.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>



</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {

        window.livewire.on('patient-added', msg => {
            $('#theModal').modal('hide')
            noty(msg)
        });
        window.livewire.on('patient-updated', msg => {
            $('#theModal').modal('hide')
            noty(msg)
        });
        window.livewire.on('patient-deleted', msg => {
            //noty
            noty(msg)
        });
        window.livewire.on('modal-show', msg => {
            $('#theModal').modal('show')
        });
        window.livewire.on('modal-hide', msg => {
            $('#theModal').modal('hide')
        });
        /* $('#theModal').on('hidden.bs.modal', function(e) {
            $('.er').css('display','none')
        }); */

        window.livewire.on('hidden.bs.modal', msg => {
            $('.er').css('display', 'none')
        });



    });

    function Confirm(id) {
        swal({
            title: 'Confirmar',
            text: '¿Deseas eliminar el registro?',
            type: 'warning',
            showCancelButton: true,
            cancelButtonText: 'Cerrar',
            cancelButtonColor: '#fff',
            confirmButtonColor: '#3b3f5c',
            confirmButtonText: 'Aceptar'

        }).then(function(result) {
            if (result.value) {
                window.livewire.emit('deleteRow', id)
                swal.close()
            }
        })
    }
</script>
<?php /**PATH D:\laragon\www\vacunas\resources\views/livewire/pos/component.blade.php ENDPATH**/ ?>