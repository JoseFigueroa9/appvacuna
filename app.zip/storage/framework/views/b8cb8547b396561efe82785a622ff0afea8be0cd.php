<div class="widget widget-chart-one" style="padding: 20px">
    <div class="widget-heading ">
        <h4 class="card-title">
            <b><?php echo e($componentName); ?> | <?php echo e($pageTitle); ?></b>
        </h4>
        <ul class="tabs tab-pills">
            <li>
                <a href="javascript:void(0)" class="tabmenu bg-dark" data-toggle="modal" data-target="#theModal">Agregar</a>
            </li>
        </ul>
    </div>
    <?php echo $__env->make('common.searchbox', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="widget-content">
        <?php if($total > 0): ?>
            <div class="table-responsive">
                <table class="table table-bordered table-striped mt-1">
                    <thead class="text-white" style="background: #3b3f5c">
                        <tr>
                            <th class="table-th text-left text-white">DNI</th>
                            <th class="table-th text-left text-white">Nombre del Paciente</th>
                            <th class="table-th text-left text-white">Vacuna</th>
                            <th class="table-th text-left text-white">Dosis</th>
                            <th class="table-th text-left text-white">Lote</th>
                            <th class="table-th text-left text-white">Fecha</th>
                            <th class="table-th text-left text-white">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td class="text-center">
                                    <a href="javascript:void(0)" wire:click.prevent="Edit(<?php echo e($patient->id); ?>)"
                                        class="btn btn-dark mtmobile" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <button
                                        onclick="Confirm('<?php echo e($item->id); ?>', 'removeItem', '¿Confirmas Eliminar el registro?')"
                                        class="btn btn-dark mbmobile">
                                        <i class="fas fa-trash-alt">

                                        </i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <h5 class="text-center text-muted">Agrega vacuna a la Ficha</h5>
        <?php endif; ?>

        <div wire:loading.inline wire:target="saveSale">
            <h4 class="text-danger text-center">Guardando Ficha...</h4>
        </div>

    </div>
</div>
<?php /**PATH D:\laragon\www\vacunas\resources\views/livewire/pos/partials/detail.blade.php ENDPATH**/ ?>